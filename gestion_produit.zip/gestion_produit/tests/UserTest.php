<?php
namespace Tests;

use PHPUnit\Framework\TestCase;
use App\Models\User;
use App\Database;
use Exception;

class UserTest extends TestCase
{
    private $db;

    protected function setUp(): void
    {
        // Initialisation de la base de données pour les tests
        $this->db = new Database();
    }

    public function testAddUser()
    {
        $uniqueEmail = "john_" . uniqid() . "@example.com";
        $user = new User("John", $uniqueEmail, "admin", $this->db);
        $result = $user->save();
        $this->assertTrue($result);
    }

    public function testAddUserEmailException()
    {
        $this->expectException(Exception::class);

        $uniqueEmail = "jane_" . uniqid() . "@example.com";
        // Ajoute un utilisateur avec un email unique
        $user1 = new User("Jane", $uniqueEmail, "user", $this->db);
        $this->assertTrue($user1->save());

        // Tente d'ajouter un autre utilisateur avec le même email
        $user2 = new User("Another Jane", $uniqueEmail, "user", $this->db);
        $user2->save(); // Doit lever une exception
    }

    public function testUpdateUser()
    {
        $uniqueEmail = "temp_" . uniqid() . "@example.com";
        $user = new User("Temp", $uniqueEmail, "user", $this->db);
        $this->assertTrue($user->save());

        // Modification du nom et sauvegarde
        $user->name = "Updated Name";
        $result = $user->save();
        $this->assertTrue($result);
    }

    public function testRemoveUser()
    {
        $uniqueEmail = "delete_" . uniqid() . "@example.com";
        $user = new User("Delete", $uniqueEmail, "user", $this->db);
        $this->assertTrue($user->save());

        // Suppression de l'utilisateur
        $result = $user->delete();
        $this->assertTrue($result);
    }

    public function testGetUsers()
    {
        $uniqueEmail = "get_" . uniqid() . "@example.com";
        $user = new User("Test", $uniqueEmail, "user", $this->db);
        $user->save();

        $users = User::all($this->db);
        $this->assertIsArray($users);
        $this->assertNotEmpty($users);
    }

    public function testInvalidUpdateThrowsException()
    {
        $this->expectException(Exception::class);
        // On tente de récupérer un utilisateur inexistant
        $user = User::find(9999, $this->db);
        $user->name = "Should Fail";
        $user->save();
    }

    public function testInvalidDeleteThrowsException()
    {
        $this->expectException(Exception::class);
        // On tente de récupérer un utilisateur inexistant
        $user = User::find(9999, $this->db);
        $user->delete();
    }
}
