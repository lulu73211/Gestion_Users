import http from 'k6/http';
import { sleep, check } from 'k6';

// 📌 Définition des paramètres de test
export const options = {
  vus: 500, // Nombre d'utilisateurs virtuels simultanés
  duration: '1m', // Durée du test (1 minute)
};

export default function () {
  const url = 'http://127.0.0.1:8080/api.php'; // URL de l’API à tester

  const payload = JSON.stringify({
    name: `User_${Math.random().toString(36).substr(2, 5)}`,
    email: `user_${Math.random().toString(36).substr(2, 5)}@example.com`,
    role: 'Utilisateur',
  });

  const params = {
    headers: {
      'Content-Type': 'application/json',
    },
  };

  // 📌 Envoi de la requête POST pour ajouter un utilisateur
  const response = http.post(url, payload, params);

  // 📊 Vérification du statut de réponse et du temps de réponse
  check(response, {
    'Statut 200': (r) => r.status === 200,
    'Réponse rapide (<500ms)': (r) => r.timings.duration < 500,
  });

  sleep(1);
}
