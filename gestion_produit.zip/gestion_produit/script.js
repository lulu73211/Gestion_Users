document.addEventListener("DOMContentLoaded", function () {
    const userForm = document.getElementById("userForm");
    const userList = document.getElementById("userList");
    const userIdField = document.getElementById("userId");
    const apiURL = "http://127.0.0.1:8080/api.php"; // Adapte si besoin d'un autre port/URL

    // Récupérer et afficher les utilisateurs
    function fetchUsers() {
        fetch(apiURL)
            .then(response => response.json())
            .then(users => {
                userList.innerHTML = "";
                users.forEach(user => {
                    const li = document.createElement("li");
                    // On inclut le rôle dans l'affichage
                    li.innerHTML = `
                        ${user.name} (${user.email}) - Rôle: ${user.role}
                        <button onclick="editUser(${user.id}, '${user.name}', '${user.email}', '${user.role}')">✏️</button>
                        <button onclick="deleteUser(${user.id})">❌</button>
                    `;
                    userList.appendChild(li);
                });
            })
            .catch(error => console.error("❌ Erreur lors de la récupération des utilisateurs :", error));
    }

    // Ajout ou mise à jour d'un utilisateur (submit du formulaire)
    userForm.addEventListener("submit", function (e) {
        e.preventDefault();

        const name = document.getElementById("name").value;
        const email = document.getElementById("email").value;
        const role = document.getElementById("role").value;  // On récupère le rôle sélectionné
        const userId = userIdField.value;

        const method = userId ? "PUT" : "POST";
        // On ajoute le champ 'role' dans les données
        const bodyData = userId
            ? { id: userId, name, email, role }
            : { name, email, role };

        fetch(apiURL, {
            method: method,
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(bodyData)
        })
        .then(response => response.json())
        .then(data => {
            if (data.error) {
                console.error("❌ Erreur API:", data.error);
                return;
            }
            // Rafraîchit la liste puis reset le formulaire
            fetchUsers();
            userForm.reset();
            userIdField.value = "";
        })
        .catch(error => console.error("❌ Erreur lors de l'ajout/mise à jour :", error));
    });

    // Édition d'un utilisateur
    window.editUser = function (id, name, email, role = 'user') {
        document.getElementById("name").value = name;
        document.getElementById("email").value = email;
        document.getElementById("role").value = role;
        userIdField.value = id;
    };

    // Suppression d'un utilisateur
    window.deleteUser = function (id) {
        fetch(`${apiURL}?id=${id}`, { method: "DELETE" })
        .then(res => res.json())
        .then(data => {
            if (data.error) {
                console.error("❌ Erreur API (delete):", data.error);
                return;
            }
            fetchUsers();
        })
        .catch(error => console.error("❌ Erreur lors de la suppression :", error));
    };

    // Charger la liste au démarrage
    fetchUsers();
});
