<?php
require_once 'UserManager.php'; // ou Database.php, selon ton implémentation
header("Content-Type: application/json");

$method = $_SERVER['REQUEST_METHOD'];
$userManager = new UserManager(); // classe qui gère la connexion et queries

try {
    // Lire le JSON du body (pour POST/PUT)
    $inputData = json_decode(file_get_contents("php://input"), true);

    if ($method === 'POST') {
        if (!isset($inputData['name']) || !isset($inputData['email']) || !isset($inputData['role'])) {
            throw new Exception("Données incomplètes (name, email, role).");
        }
        $userManager->addUser($inputData['name'], $inputData['email'], $inputData['role']);
        echo json_encode(["message" => "Utilisateur ajouté avec succès"]);
    
    } elseif ($method === 'GET') {
        // Renvoie la liste complète
        echo json_encode($userManager->getUsers());

    } elseif ($method === 'DELETE') {
        if (!isset($_GET['id'])) {
            throw new Exception("ID utilisateur requis pour suppression.");
        }
        $userManager->removeUser((int)$_GET['id']);
        echo json_encode(["message" => "Utilisateur supprimé"]);

    } elseif ($method === 'PUT') {
        if (!isset($inputData['id']) || !isset($inputData['name']) || !isset($inputData['email']) || !isset($inputData['role'])) {
            throw new Exception("Données incomplètes pour la mise à jour (id, name, email, role).");
        }
        $userManager->updateUser((int)$inputData['id'], $inputData['name'], $inputData['email'], $inputData['role']);
        echo json_encode(["message" => "Utilisateur mis à jour"]);
    } else {
        throw new Exception("Méthode HTTP non supportée.");
    }
} catch (Exception $e) {
    http_response_code(400);
    echo json_encode(["error" => $e->getMessage()]);
}
