<?php
require_once 'UserManager.php';

$userManager = new UserManager();
$users = $userManager->getUsers();

echo "<pre>";
print_r($users);
echo "</pre>";
?>
