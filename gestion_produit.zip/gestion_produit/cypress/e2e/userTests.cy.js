describe('Gestion des Utilisateurs - Tests E2E', () => {
  
  beforeEach(() => {
    cy.visit('http://127.0.0.1:8080');
  });

  it('Ajout d’un utilisateur et vérification de son affichage', () => {
      // Génère un email unique pour éviter les conflits
      const uniqueEmail = `user_${Date.now()}@example.com`;

      // Remplissage du formulaire d'ajout d'utilisateur
      cy.get('#name').type('Test');
      cy.get('#email').type(uniqueEmail);

      // Soumission du formulaire
      cy.get('#submit-user').click();

      // Vérifie que l'utilisateur ajouté est affiché dans la liste
      cy.contains('Test').should('be.visible');
      cy.contains(uniqueEmail).should('be.visible');
  });

  it('Modification des informations de l’utilisateur', () => {
      const uniqueEmail = `user_${Date.now()}@example.com`;

      // Ajout d'un utilisateur à modifier
      cy.get('#name').type('TestEdit');
      cy.get('#email').type(uniqueEmail);
      cy.get('#submit-user').click();

      // Recherche l'utilisateur ajouté
      cy.contains(uniqueEmail).parent().within(() => {
          cy.get('button[data-action="edit"]').click();
      });

      // Modification du nom et soumission
      cy.get('#name').clear().type('Updated Name');
      cy.get('#submit-user').click();

      // Vérification que la modification est affichée
      cy.contains('Updated Name').should('be.visible');
  });

  it('Suppression de l’utilisateur et vérification de sa disparition', () => {
      const uniqueEmail = `user_${Date.now()}@example.com`;

      // Ajout d'un utilisateur à supprimer
      cy.get('#name').type('DeleteMe');
      cy.get('#email').type(uniqueEmail);
      cy.get('#submit-user').click();

      // Recherche et suppression de l'utilisateur
      cy.contains(uniqueEmail).parent().within(() => {
          cy.get('button[data-action="delete"]').click();
      });

      // Vérification que l'utilisateur n'existe plus
      cy.contains(uniqueEmail).should('not.exist');
  });

});
