<?php
namespace App\Models;

use App\Database;
use Exception;

class User {
    public $id;
    public $name;
    public $email;
    private $db;

    // 🔥 CORRECTION : Ajout de $db en argument pour éviter une nouvelle instance inutile
    public function __construct($name, $email, $id = null, Database $db = null) {
        $this->id = $id;
        $this->name = $name;
        $this->email = $email;
        $this->db = $db ?? new Database();
    }

    public function save() {
        if ($this->id) {
            return $this->db->updateUser($this->id, [
                "name" => $this->name,
                "email" => $this->email
            ], $this->id);
        } else {
            return $this->db->addUser($this->name, $this->email);
        }
    }

    public static function find($id) {
        $db = new Database();
        $users = $db->getUsers();
        
        foreach ($users as $user) {
            if ($user["id"] == $id) {
                return new User($user["name"], $user["email"], $user["id"], $db);
            }
        }

        throw new Exception("Utilisateur introuvable");
    }

    public static function all() {
        $db = new Database();
        return $db->getUsers();
    }

    public function delete() {
        return $this->db->deleteUser($this->id);
    }
}
