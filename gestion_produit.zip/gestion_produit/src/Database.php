<?php
namespace App;

use PDO;
use PDOException;
use Exception;

class Database {
    private $pdo;

    public function __construct() {
        $dsn = "mysql:host=127.0.0.1;dbname=user_management;charset=utf8mb4";
        $user = "root";
        $password = ""; // Pas de mot de passe pour MySQL

        try {
            $this->pdo = new PDO($dsn, $user, $password, [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
            ]);
        } catch (PDOException $e) {
            die(json_encode(["error" => "Erreur de connexion : " . $e->getMessage()]));
        }
    }

    public function addUser($name, $email) {
        try {
            $stmt = $this->pdo->prepare("INSERT INTO users (name, email) VALUES (:name, :email)");
            $stmt->execute([
                'name'  => $name,
                'email' => $email
            ]);
            return ["message" => "Utilisateur ajouté avec succès", "id" => $this->pdo->lastInsertId()];
        } catch (PDOException $e) {
            return ["error" => "Échec de l'ajout : " . $e->getMessage()];
        }
    }

    public function updateUser($id, $name, $email) {
        try {
            $stmt = $this->pdo->prepare("UPDATE users SET name = :name, email = :email WHERE id = :id");
            $stmt->execute([
                'id'    => $id,
                'name'  => $name,
                'email' => $email
            ]);

            if ($stmt->rowCount() === 0) {
                return ["error" => "Utilisateur inexistant ou données identiques."];
            }

            return ["message" => "Utilisateur mis à jour avec succès"];
        } catch (PDOException $e) {
            return ["error" => "Échec de la mise à jour : " . $e->getMessage()];
        }
    }

    public function deleteUser($id) {
        try {
            $stmt = $this->pdo->prepare("DELETE FROM users WHERE id = :id");
            $stmt->execute(['id' => $id]);

            if ($stmt->rowCount() === 0) {
                return ["error" => "Utilisateur inexistant, suppression impossible."];
            }

            return ["message" => "Utilisateur supprimé avec succès"];
        } catch (PDOException $e) {
            return ["error" => "Échec de la suppression : " . $e->getMessage()];
        }
    }

    public function getUsers() {
        try {
            $stmt = $this->pdo->query("SELECT * FROM users");
            return $stmt->fetchAll();
        } catch (PDOException $e) {
            return ["error" => "Échec de la récupération des utilisateurs : " . $e->getMessage()];
        }
    }
}
