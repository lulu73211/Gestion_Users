<?php

class UserManager {
    private PDO $db;

    public function __construct() {
    // Ici, on utilise le socket /tmp/mysql.sock
    $dsn = "mysql:unix_socket=/tmp/mysql.sock;dbname=user_management;charset=utf8mb4";

    $username = "root";  // Adaptez selon votre config
    $password = "";      // Idem

    $this->db = new PDO($dsn, $username, $password, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
    ]);
}


    /**
     * Ajoute un utilisateur
     * @param string $name
     * @param string $email
     * @param string $role
     */
    public function addUser(string $name, string $email, string $role = 'user'): void {
        // Vérification simple (optionnelle)
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            throw new InvalidArgumentException("Email invalide.");
        }

        $stmt = $this->db->prepare("INSERT INTO users (name, email, role) VALUES (:name, :email, :role)");
        $stmt->execute([
            'name'  => $name,
            'email' => $email,
            'role'  => $role
        ]);
    }

    /**
     * Supprime un utilisateur
     * @param int $id
     */
    public function removeUser(int $id): void {
        $stmt = $this->db->prepare("DELETE FROM users WHERE id = :id");
        $stmt->execute(['id' => $id]);
    }

    /**
     * Retourne la liste de tous les utilisateurs
     * @return array
     */
    public function getUsers(): array {
        $stmt = $this->db->query("SELECT id, name, email, role FROM users");
        return $stmt->fetchAll();
    }

    /**
     * Retourne un utilisateur spécifique
     * @param int $id
     * @return array
     * @throws Exception si l’utilisateur n’existe pas
     */
    public function getUser(int $id): array {
        $stmt = $this->db->prepare("SELECT id, name, email, role FROM users WHERE id = :id");
        $stmt->execute(['id' => $id]);
        $user = $stmt->fetch();

        if (!$user) {
            throw new Exception("Utilisateur introuvable.");
        }
        return $user;
    }

    /**
     * Met à jour un utilisateur
     * @param int $id
     * @param string $name
     * @param string $email
     * @param string $role
     */
    public function updateUser(int $id, string $name, string $email, string $role = 'user'): void {
        $stmt = $this->db->prepare("
            UPDATE users 
            SET name = :name, email = :email, role = :role
            WHERE id = :id
        ");
        $stmt->execute([
            'id'    => $id,
            'name'  => $name,
            'email' => $email,
            'role'  => $role
        ]);
    }
}
